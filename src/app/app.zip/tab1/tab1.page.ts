import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonContent } from '@ionic/angular'; // <-- 1. Importa IonContent
import { trigger, transition, style, animate, query, group } from '@angular/animations';

@Component({
  selector: 'app-tab1',
  templateUrl: './tab1.page.html',
  styleUrls: ['./tab1.page.scss'],
  standalone: true,
  imports: [CommonModule, IonContent], // <-- 2. Agrégalo al arreglo de imports
  animations: [
    trigger('stepAnimation', [
      transition('1 => 2, 2 => 3', [
        query(':enter, :leave', style({ position: 'absolute', width: '80%', left: '10%' }), { optional: true }),
        query(':enter', style({ transform: 'translateX(50%)', opacity: 0 }), { optional: true }),
        group([
          query(':leave', animate('800ms cubic-bezier(0.68, -0.55, 0.265, 1.55)', 
            style({ transform: 'scale(0.8)', opacity: 0 })), { optional: true }),
          query(':enter', animate('800ms cubic-bezier(0.68, -0.55, 0.265, 1.55)', 
            style({ transform: 'translateX(0)', opacity: 1 })), { optional: true })
        ])
      ]),
      transition('3 => 2, 2 => 1', [
        query(':enter, :leave', style({ position: 'absolute', width: '80%', left: '10%' }), { optional: true }),
        query(':enter', style({ transform: 'scale(0.8)', opacity: 0 }), { optional: true }),
        group([
          query(':leave', animate('800ms cubic-bezier(0.68, -0.55, 0.265, 1.55)', 
            style({ transform: 'translateX(50%)', opacity: 0 })), { optional: true }),
          query(':enter', animate('800ms cubic-bezier(0.68, -0.55, 0.265, 1.55)', 
            style({ transform: 'scale(1)', opacity: 1 })), { optional: true })
        ])
      ])
    ])
  ]
})
export class Tab1Page {
  currentStep: number = 1;

  next() {
    if (this.currentStep < 3) {
      this.currentStep++;
    }
  }

  previous() {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  submit() {
    console.log('Formulario enviado!');
  }
}